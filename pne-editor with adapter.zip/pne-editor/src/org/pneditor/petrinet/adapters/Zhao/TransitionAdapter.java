package org.pneditor.petrinet.adapters.Zhao;

import org.pneditor.petrinet.AbstractTransition;


public class TransitionAdapter extends AbstractTransition {

	public TransitionAdapter(String label) {
		super(label);
	}
}
