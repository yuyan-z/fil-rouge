/**
 * 
 */
/**
 * @author Yuyan Zhao
 *
 */
package org.pneditor.petrinet.adapters.Zhao;